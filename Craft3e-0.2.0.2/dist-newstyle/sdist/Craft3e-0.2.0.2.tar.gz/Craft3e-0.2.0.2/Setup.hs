module Setup where

main :: IO ()

main = putStrLn "Welcome to the code package for www.haskellcraft.com."
