README 

Code for Haskell the Craft of Functional Programming, 3rd ed.

Files for chapter N are in ChapterN.hs except

Chapter 12
	Chapter12.hs
	Index.hs	-- Indexing
	RPS.hs 		-- Rock - Paper - Scissors
	RegExp.hs	-- Regular expressions

Chapter 14
	Chapter14_1.s
	Chapter14_2.s

Chapter 15
	Folders containing the modules:
		Huffman 

Chapter 16
	Folders containing the modules:
		AbsTypes 
		Simulation

Chapter 19
	Pic.hs
	RegExp.hs
	QCfuns.hs
	QC.hs

Chapter 20
	Chapter20.hs
	PerformanceI.hs
	PerformanceIA.hs
	PerformanceIS.hs