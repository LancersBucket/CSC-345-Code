module Doe where

    maxD x y 
        | x>y = x

    maxD x y 
        = y
